from django.urls import path

from web.views import index, userdetails, delete_integration, stateDetails
from django.conf.urls import url

urlpatterns = [
    path("", index, name="home"),
    path("user/", userdetails, name="home"),
    path('user/<int:integrationId>/delete/', delete_integration, name='home'),
    path('user/<int:id>/state/', stateDetails, name = "home")


    #path("(?P<user_integration_id>)/delete/", delete_integration, name="home")
    #path("(?P<article_id>\d+)/delete/",delete_integration, name="home")

]
